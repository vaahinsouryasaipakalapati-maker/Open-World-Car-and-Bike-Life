console.log('Open World Car & Bike Life starting...');
// TODO: initialize Babylon.js scene
